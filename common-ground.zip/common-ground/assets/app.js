/* Common Ground core: storage, seed data, auth, shared UI. Requires geo/index.js first. */
(function(){
'use strict';
const CG = window.CG = {};
const DB_KEY='cg_db_v2', SESSION_KEY='cg_session', ADMIN_KEY='cg_admin', COUNTRY_KEY='cg_country', NAV_KEY='cg_nav';
const ADMIN_PASSWORD='commonground';
const mem={};
const ls={
  get(k){try{return localStorage.getItem(k)}catch(e){return mem[k]??null}},
  set(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}},
  del(k){try{localStorage.removeItem(k)}catch(e){delete mem[k]}}
};
CG.ls=ls;
CG.COUNTRIES={NG:'Nigeria',GH:'Ghana',KE:'Kenya'};
CG.GEO=window.CG_GEOINDEX;

/* ---------- utilities ---------- */
const esc=CG.esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
CG.fmt=n=>Number(n||0).toLocaleString('en-GB');
CG.pct=n=>n==null?'–':(Math.round(n*10)/10)+'%';
CG.uid=p=>(p||'id')+'_'+Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-3);
CG.date=t=>new Date(t).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});
CG.ago=t=>{const s=(Date.now()-t)/1000;if(s<60)return'just now';if(s<3600)return Math.floor(s/60)+' min ago';if(s<86400)return Math.floor(s/3600)+' h ago';const d=Math.floor(s/86400);return d<30?d+' d ago':CG.date(t)};
CG.$=(s,r)=>(r||document).querySelector(s);CG.$$=(s,r)=>[...(r||document).querySelectorAll(s)];
function rng(seed){let s=seed>>>0||1;return()=>{s^=s<<13;s>>>=0;s^=s>>17;s^=s<<5;s>>>=0;return s/4294967296}}
function hash(str){let h=2166136261;for(const c of str){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}

/* ---------- geography lookup ---------- */
const areaIdx={};
for(const cc in CG.GEO){const g=CG.GEO[cc];g.adm1.forEach(([id,n])=>areaIdx[id]={id,name:n,level:1,cc});g.adm2.forEach(([id,n,p])=>areaIdx[id]={id,name:n,level:2,cc,parent:p})}
CG.area=id=>areaIdx[id]||null;
CG.areaName=id=>areaIdx[id]?areaIdx[id].name:'';
CG.areaLabel=(cc,a1,a2)=>[a2&&CG.areaName(a2),a1&&CG.areaName(a1),CG.COUNTRIES[cc]].filter(Boolean).join(', ');
CG.adm1List=cc=>CG.GEO[cc].adm1.map(([id,name])=>({id,name}));
CG.adm2List=(cc,p)=>CG.GEO[cc].adm2.filter(a=>!p||a[2]===p).map(([id,name,parent])=>({id,name,parent}));
CG.geoCache={};
CG.loadGeo=cc=>{
  if(window.CG_GEO&&window.CG_GEO[cc])return Promise.resolve(window.CG_GEO[cc]);
  if(CG.geoCache[cc])return CG.geoCache[cc];
  const base=(document.querySelector('script[src*="assets/app.js"]')?.getAttribute('src')||'assets/app.js').replace('app.js','');
  return CG.geoCache[cc]=new Promise((res,rej)=>{const s=document.createElement('script');s.src=base+'geo/'+cc.toLowerCase()+'.js';s.onload=()=>res(window.CG_GEO[cc]);s.onerror=()=>{delete CG.geoCache[cc];rej(new Error('Could not load map data for '+cc))};document.head.appendChild(s)});
};


/* demo responses are generated deterministically at load, never stored */
const HUBS={'Lagos':5,'Kano':3.5,'Federal Capital Territory':2.5,'Rivers':2.5,'Oyo':2.5,'Kaduna':2,'Greater Accra':4,'Ashanti':3.5,'Nairobi':4,'Mombasa':2.5,'Kiambu':2,'Nakuru':1.8,'Kisumu':1.8};
function areaPicker(r){const cum={};
  for(const cc in CG.GEO){let t=0;cum[cc]=CG.GEO[cc].adm2.map(([id,n,p])=>{t+=(HUBS[CG.areaName(p)]||1)*(0.55+r()*1.3);return [id,p,t]})}
  return cc=>{const a=cum[cc];const x=r()*a[a.length-1][2];let lo=0,hi=a.length-1;while(lo<hi){const m=(lo+hi)>>1;if(a[m][2]<x)lo=m+1;else hi=m}return a[lo]}}
const DEMO_N={s_cost:16000,s_trust:14000,s_commute:9000,s_power:8000,s_water:4200,s_momo:4500,s_school:5000};
const TEXT_POOL={
  s_cost:['Lower food prices at the market','Stable electricity so I can work','Cheaper transport to work','Help with school fees','A pay rise that matches prices','Lower rent'],
  s_commute:['Potholes near the junction slow everything down','Too few buses in the morning','Fares change every week','Traffic at the bridge adds an hour','No street lights on the way home']};
function genDemo(d){const out=[];if(d.demoOff)return out;const now=Date.now();
  for(const s of d.surveys){const N=DEMO_N[s.id];if(!N||s.status==='draft')continue;const r=rng(hash(s.id+'v2'));const pickArea=areaPicker(r);const pick=a=>a[Math.floor(r()*a.length)];
    const span=Math.max(DAY,Math.min(now-s.created,30*DAY));
    for(let i=0;i<N;i++){
      const cc=s.country==='ALL'?(r()<.55?'NG':r()<.45?'GH':'KE'):s.country;
      const a=pickArea(cc);
      const bias=((hash(a[1]+s.id)%1000)/1000-.5)*2.4+((hash(a[0]+s.id)%1000)/1000-.5)*1.2;
      const ans={};
      for(const q of s.questions){
        if(q.type==='text'){if(r()<.25&&TEXT_POOL[s.id])ans[q.id]=pick(TEXT_POOL[s.id]);continue}
        const k=q.options.length,mid=(k-1)/2;
        const w=q.options.map((_,j)=>Math.exp(bias*(j-mid)*.45+(r()-.5)*.3));
        if(q.type==='multi'){ans[q.id]=q.options.filter((_,j)=>r()<Math.min(.85,.18+w[j]*.18));if(!ans[q.id].length)ans[q.id]=[pick(q.options)];continue}
        let tot=w.reduce((x,y)=>x+y,0),x=r()*tot,ch=0;for(let j=0;j<k;j++){x-=w[j];if(x<=0){ch=j;break}}
        ans[q.id]=q.options[ch];
      }
      out.push({id:'d'+i+s.id,surveyId:s.id,userId:'demo',country:cc,adm1:a[1],adm2:a[0],answers:ans,at:s.created+Math.floor(r()*span),demo:true});
    }}
  return out}

/* ---------- seed data ---------- */
const DAY=86400000;
function seed(){
  const now=Date.now();
  const surveys=[
    {id:'s_cost',title:'Cost of living check-in',desc:'How households are coping with prices, and which costs are rising fastest.',type:'community',sponsor:'',country:'ALL',adm1:'',topic:'Economy',minutes:3,points:40,status:'live',created:now-40*DAY,questions:[
      {id:'q1',type:'single',text:'Compared with a year ago, how is your household managing financially?',options:['Much better','A little better','About the same','A little worse','Much worse']},
      {id:'q2',type:'multi',text:'Which costs have risen the most for you? Choose all that apply.',options:['Food','Transport','Rent','Electricity or fuel','School fees','Healthcare']},
      {id:'q3',type:'scale',text:'How confident are you about your finances over the next six months?',options:['1','2','3','4','5'],low:'Not confident',high:'Very confident'},
      {id:'q4',type:'text',text:'What one change would help your household most?'}]},
    {id:'s_commute',title:'Daily commute and transport fares',desc:'Part of a longer study on transport affordability in Nigerian cities.',type:'research',sponsor:'',country:'NG',adm1:'',topic:'Mobility',minutes:4,points:60,status:'live',created:now-32*DAY,questions:[
      {id:'q1',type:'single',text:'How do you usually travel to work, school or market?',options:['Bus or danfo','Okada or keke','Own car','Walk','Ride-hailing app','I do not travel regularly']},
      {id:'q2',type:'single',text:'How has your weekly transport spending changed over the last three months?',options:['Increased a lot','Increased a little','No change','Decreased']},
      {id:'q3',type:'scale',text:'How would you rate road conditions on your usual route?',options:['1','2','3','4','5'],low:'Very poor',high:'Very good'},
      {id:'q4',type:'text',text:'Describe one problem on your usual route.'}]},
    {id:'s_trust',title:'Trust in local government',desc:'How people rate their local council and what they want it to prioritise.',type:'community',sponsor:'',country:'ALL',adm1:'',topic:'Governance',minutes:3,points:40,status:'live',created:now-25*DAY,questions:[
      {id:'q1',type:'single',text:'How much do you trust your local government council to act in your interest?',options:['A great deal','A fair amount','Not very much','Not at all','Don\'t know']},
      {id:'q2',type:'multi',text:'What should your local council prioritise this year?',options:['Roads','Water supply','Waste collection','Security','Health centres','Schools','Markets']},
      {id:'q3',type:'single',text:'Have you contacted your local council in the last 12 months?',options:['Yes','No']}]},
    {id:'s_water',title:'Water and sanitation access',desc:'Where households get water and how reliable it is.',type:'community',sponsor:'',country:'GH',adm1:'',topic:'Public services',minutes:3,points:40,status:'live',created:now-18*DAY,questions:[
      {id:'q1',type:'single',text:'What is your main source of drinking water?',options:['Piped into home','Public standpipe','Borehole or well','Sachet or bottled water','Tanker or vendor']},
      {id:'q2',type:'single',text:'In the last month, how often was your water supply interrupted?',options:['Never','Once or twice','Weekly','Most days']},
      {id:'q3',type:'scale',text:'How satisfied are you with waste collection where you live?',options:['1','2','3','4','5'],low:'Very dissatisfied',high:'Very satisfied'}]},
    {id:'s_momo',title:'Mobile money and digital payments',desc:'How people pay, save and send money. Sponsored research with full disclosure.',type:'sponsored',sponsor:'Demo Fintech Partner (fictional)',country:'KE',adm1:'',topic:'Technology',minutes:5,points:150,status:'live',created:now-12*DAY,questions:[
      {id:'q1',type:'single',text:'How often do you use mobile money?',options:['Daily','Weekly','Monthly','Rarely','Never']},
      {id:'q2',type:'multi',text:'What do you use mobile money for?',options:['Paying bills','Sending money to family','Buying goods','Saving','Receiving wages','Loans']},
      {id:'q3',type:'scale',text:'How much do you trust digital payments to be safe?',options:['1','2','3','4','5'],low:'No trust',high:'Full trust'}]},
    {id:'s_power',title:'Electricity supply reliability',desc:'Hours of grid supply, backup power costs and the effect on work.',type:'research',sponsor:'',country:'NG',adm1:'',topic:'Public services',minutes:4,points:80,status:'live',created:now-8*DAY,questions:[
      {id:'q1',type:'single',text:'On a typical day, how many hours of grid electricity do you get?',options:['Less than 4 hours','4 to 8 hours','8 to 16 hours','More than 16 hours','No grid connection']},
      {id:'q2',type:'single',text:'What backup power do you use most?',options:['Petrol generator','Diesel generator','Solar and battery','Inverter only','None']},
      {id:'q3',type:'scale',text:'How much does unreliable power affect your income?',options:['1','2','3','4','5'],low:'Not at all',high:'Severely'}]},
    {id:'s_youth',title:'Youth employment outlook',desc:'Draft questionnaire for 18 to 35 year olds on jobs, skills and side income.',type:'community',sponsor:'',country:'ALL',adm1:'',topic:'Jobs',minutes:4,points:50,status:'draft',created:now-3*DAY,questions:[
      {id:'q1',type:'single',text:'What best describes your current work situation?',options:['Full-time job','Part-time job','Self-employed','Studying','Looking for work']},
      {id:'q2',type:'multi',text:'Which skills would most improve your job prospects?',options:['Digital skills','Trade skills','Business skills','Languages','Driving']}]},
    {id:'s_school',title:'School fees and learning costs',desc:'Closed fieldwork on what families spend on education.',type:'community',sponsor:'',country:'NG',adm1:'',topic:'Education',minutes:3,points:40,status:'closed',created:now-70*DAY,questions:[
      {id:'q1',type:'single',text:'How many children in your household attend school?',options:['None','1','2','3','4 or more']},
      {id:'q2',type:'single',text:'Have school costs forced you to cut other spending this term?',options:['Yes, a lot','Yes, a little','No']}]}
  ];
  const r=rng(20261024);
  const pickArea=areaPicker(r);
  const users=[];
  const first=['Adaeze','Tunde','Amina','Kwame','Akosua','Wanjiru','Otieno','Chidi','Fatima','Yaw','Njeri','Emeka','Zainab','Kofi','Achieng','Bola','Musa','Esi','Kamau','Ngozi','Ibrahim','Abena','Mwangi','Funke','Halima','Kojo','Wambui','Segun','Hauwa','Ama'];
  first.forEach((f,i)=>{const cc=i<14?'NG':i<22?'GH':'KE';const a=pickArea(cc);users.push({id:'u_demo'+i,email:f.toLowerCase()+'.demo'+i+'@gmail.com',name:f+' (demo)',country:cc,adm1:a[1],adm2:a[0],verified:r()>.2,status:r()>.93?'suspended':'active',points:Math.floor(r()*900),joined:now-Math.floor(r()*120)*DAY,demo:true})});
  const responses=[];
  const findA1=(cc,name)=>CG.GEO[cc].adm1.find(a=>a[1]===name)[0];
  const findA2=(cc,a1,name)=>{const x=CG.GEO[cc].adm2.find(a=>a[2]===a1&&a[1]===name);return x?x[0]:''};
  const lag=findA1('NG','Lagos'),kan=findA1('NG','Kano'),acc=findA1('GH','Greater Accra'),nai=findA1('KE','Nairobi'),oyo=findA1('NG','Oyo');
  const petitions=[
    {id:'p_roads',title:'Safer roads around schools and markets',ask:'Install pedestrian crossings, street lighting and speed calming on roads next to primary schools and daily markets, starting with the five busiest junctions identified by residents.',target:'State Ministry of Works',category:'Transport and road safety',country:'NG',adm1:lag,adm2:findA2('NG',lag,'Surulere'),creatorId:'u_demo0',status:'open',base:8420,goal:10000,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:612,no:238},created:now-21*DAY,featured:true,updates:[{at:now-6*DAY,text:'Petition delivered to the ward councillor. Awaiting a meeting date.'}]},
    {id:'p_water',title:'Fix the burst mains on Ring Road',ask:'Repair the main water line that has leaked for six weeks and publish a schedule for restoring supply to affected neighbourhoods.',target:'Ghana Water Limited, Accra East',category:'Public services',country:'GH',adm1:acc,adm2:findA2('GH',acc,'Accra Metropolis')||'',creatorId:'u_demo15',status:'open',base:2140,goal:5000,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:201,no:40},created:now-14*DAY,updates:[]},
    {id:'p_waste',title:'Weekly waste collection in informal settlements',ask:'Extend scheduled waste collection to every ward in the county, with skips placed at agreed collection points.',target:'Nairobi City County Environment Department',category:'Environment',country:'KE',adm1:nai,adm2:findA2('KE',nai,'Kibra'),creatorId:'u_demo24',status:'open',base:5310,goal:7500,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:420,no:66},created:now-30*DAY,updates:[{at:now-2*DAY,text:'County officials agreed to pilot collection in two wards.'}]},
    {id:'p_clinic',title:'Open the completed primary health centre',ask:'Staff and equip the primary health centre that was completed last year but has not opened to patients.',target:'Kano State Primary Health Care Board',category:'Healthcare',country:'NG',adm1:kan,adm2:findA2('NG',kan,'Nassarawa'),creatorId:'u_demo3',status:'open',base:3905,goal:5000,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:350,no:21},created:now-9*DAY,updates:[]},
    {id:'p_market',title:'Restore power to Bodija market stalls',ask:'Reconnect the market transformer and agree a fair maintenance levy with traders.',target:'Ibadan Electricity Distribution Company',category:'Jobs and livelihoods',country:'NG',adm1:oyo,adm2:findA2('NG',oyo,'Ibadan North'),creatorId:'u_demo6',status:'closed',base:6120,goal:6000,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:540,no:30},created:now-80*DAY,updates:[{at:now-40*DAY,text:'Victory: the transformer was replaced and power restored.'}]},
    {id:'p_bus',title:'Add evening bus routes for shift workers',ask:'Run buses until 11pm on the three main corridors used by factory and hospital shift workers.',target:'Lagos Metropolitan Area Transport Authority',category:'Transport and road safety',country:'NG',adm1:lag,adm2:findA2('NG',lag,'Ikeja'),creatorId:'u_demo1',status:'pending',base:0,goal:2000,signatures:[],votes:{yes:0,no:0},baseVotes:{yes:0,no:0},created:now-1*DAY,updates:[]}
  ];
  const articles=[
    {id:'a_transport',title:'Transport costs are changing how people move through their cities.',dek:'Commuters report rising fares and longer journeys. The pattern differs sharply between local government areas.',topic:'Mobility',surveyId:'s_commute',author:'Common Ground Research Desk',status:'published',date:now-5*DAY,mins:6,featured:true,body:'Transport is one of the first places households feel price changes. In our daily commute study, contributors described how fares, route choices and journey times have shifted over the last three months.\n\nThe headline picture hides large local differences. Use the geographic explorer to compare local government areas, and note that areas with fewer than five responses are not shaded, to protect respondents and avoid over-reading small samples.\n\nThis is demonstration content. A published article would state the fieldwork dates, the achieved sample, weighting, the margin of error and any limitations, and would link to the full question wording.'},
    {id:'a_water',title:'What does reliable water mean at neighbourhood level?',dek:'How survey responses and service access data can be combined to show where supply breaks down.',topic:'Public services',surveyId:'s_water',author:'Common Ground Research Desk',status:'published',date:now-11*DAY,mins:4,body:'Water reliability is usually reported as a single national number. Our water and sanitation survey asks contributors in Ghana where their water comes from and how often supply is interrupted.\n\nDistrict-level results show that interruption rates are uneven even within the same region. Demonstration figures only.'},
    {id:'a_trust',title:'Who trusts their local council, and why?',dek:'Trust in local government varies more between neighbouring areas than between countries.',topic:'Governance',surveyId:'s_trust',author:'Common Ground Research Desk',status:'published',date:now-16*DAY,mins:5,body:'Local councils are the level of government closest to people, yet they are rarely measured. This survey runs in all three launch countries.\n\nThe map view lets readers compare trust between states, regions and counties, and then drill into local areas. Demonstration figures only.'},
    {id:'a_power',title:'The hidden cost of backup power for small businesses.',dek:'Generators, fuel and lost hours: what unreliable supply costs traders.',topic:'Small business',surveyId:'s_power',author:'Common Ground Research Desk',status:'draft',date:now-1*DAY,mins:5,body:'Draft. Fieldwork is still open. This article will be published when the sample is complete and reviewed.'}
  ];
  const activity=[
    {at:now-2*3600e3,text:'Petition "Add evening bus routes for shift workers" submitted for review'},
    {at:now-8*DAY,text:'Survey "Electricity supply reliability" went live'},
    {at:now-5*DAY,text:'Article "Transport costs are changing…" published'},
    {at:now-12*DAY,text:'Sponsored survey "Mobile money and digital payments" went live'}
  ];
  return {version:1,seededAt:now,surveys,responses,users,petitions,articles,activity};
}

/* ---------- store ---------- */
let db=null;
CG.db=()=>{
  if(db)return db;
  const raw=ls.get(DB_KEY);
  if(raw){try{db=JSON.parse(raw)}catch(e){db=null}}
  if(!db){db=seed();CG.save()}
  db.responses=genDemo(db).concat((db.responses||[]).filter(r=>!r.demo));
  return db;
};
CG.save=()=>{const txt=JSON.stringify(db,(k,v)=>k==='responses'&&Array.isArray(v)?v.filter(r=>!r.demo):v);try{localStorage.setItem(DB_KEY,txt)}catch(e){mem[DB_KEY]=txt}};
CG.resetDemo=()=>{db=seed();CG.save();db=null;CG.db()};
CG.log=text=>{CG.db().activity.unshift({at:Date.now(),text});CG.db().activity=CG.db().activity.slice(0,200);CG.save()};

/* ---------- session ---------- */
CG.user=()=>{const id=ls.get(SESSION_KEY);return id?CG.db().users.find(u=>u.id===id)||null:null};
CG.signOut=()=>{ls.del(SESSION_KEY);location.reload()};
CG.isAdmin=()=>ls.get(ADMIN_KEY)==='1';
CG.adminLogin=pw=>{if(pw===ADMIN_PASSWORD){ls.set(ADMIN_KEY,'1');return true}return false};
CG.adminLogout=()=>{ls.del(ADMIN_KEY)};
CG.country=()=>{const c=ls.get(COUNTRY_KEY);return CG.COUNTRIES[c]?c:'NG'};
CG.setCountry=c=>{ls.set(COUNTRY_KEY,c)};
CG.go=(href,params)=>{try{sessionStorage.setItem(NAV_KEY,JSON.stringify(params||{}))}catch(e){mem[NAV_KEY]=JSON.stringify(params||{})}location.href=href};
CG.params=()=>{let p={};try{p=JSON.parse(sessionStorage.getItem(NAV_KEY)||'{}')}catch(e){try{p=JSON.parse(mem[NAV_KEY]||'{}')}catch(_){}}
  const q=new URLSearchParams(location.search);q.forEach((v,k)=>p[k]=v);return p};

/* ---------- survey helpers ---------- */
CG.surveyResponses=id=>CG.db().responses.filter(r=>r.surveyId===id);
CG.hasTaken=(sid,uid)=>CG.db().responses.some(r=>r.surveyId===sid&&r.userId===uid);
CG.eligible=(s,u)=>{if(!u)return{ok:false,why:'Sign in to take part'};
  if(u.status==='suspended')return{ok:false,why:'Your account is suspended'};
  if(!u.verified)return{ok:false,why:'Complete the human check on your account page'};
  if(s.status!=='live')return{ok:false,why:'This survey is not open'};
  if(s.country!=='ALL'&&s.country!==u.country)return{ok:false,why:'Open to contributors in '+CG.COUNTRIES[s.country]+' only'};
  if(s.adm1&&s.adm1!==u.adm1)return{ok:false,why:'Open to contributors in '+CG.areaName(s.adm1)+' only'};
  if(CG.hasTaken(s.id,u.id))return{ok:false,why:'You have already completed this survey',done:true};
  return{ok:true}};
CG.typeLabel=t=>({community:'Community survey',research:'Research project',sponsored:'Sponsored survey'}[t]||t);
CG.surveyArea=s=>s.country==='ALL'?'Nigeria, Ghana, Kenya':(s.adm1?CG.areaName(s.adm1)+', ':'')+CG.COUNTRIES[s.country];

/* aggregate a metric across areas. level 1 groups by adm1, level 2 by adm2 */
CG.MIN_N=5;
CG.aggregate=(cc,level,opt)=>{
  opt=opt||{};const key=level===1?'adm1':'adm2';const out={};
  const res=CG.db().responses.filter(r=>r.country===cc&&(!opt.surveyId||r.surveyId===opt.surveyId)&&(!opt.parent||r.adm1===opt.parent));
  for(const r of res){const k=r[key];if(!k)continue;const o=out[k]||(out[k]={n:0,hit:0});o.n++;
    if(opt.qid&&opt.option!=null){const a=r.answers[opt.qid];if(Array.isArray(a)?a.includes(opt.option):a===opt.option)o.hit++}}
  for(const k in out){out[k].share=out[k].n>=CG.MIN_N?out[k].hit/out[k].n*100:null}
  return out;
};

/* ---------- toast & modal ---------- */
CG.toast=msg=>{let t=CG.$('#cgToast');if(!t){t=document.createElement('div');t.id='cgToast';t.className='toast';t.setAttribute('role','status');document.body.appendChild(t)}
  t.textContent=msg;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2600)};
CG.modal=(html,opts)=>{opts=opts||{};let bg=CG.$('#cgModal');if(!bg){bg=document.createElement('div');bg.id='cgModal';bg.className='modal-bg';bg.innerHTML='<div class="modal" role="dialog" aria-modal="true"></div>';document.body.appendChild(bg);
    bg.addEventListener('click',e=>{if(e.target===bg)CG.closeModal()});document.addEventListener('keydown',e=>{if(e.key==='Escape')CG.closeModal()})}
  const m=bg.firstChild;m.className='modal'+(opts.wide?' wide':'');m.innerHTML=html;bg.classList.add('open');
  CG.$$('[data-close]',m).forEach(b=>b.onclick=CG.closeModal);setTimeout(()=>{const f=m.querySelector('input,select,textarea,button:not([data-close])');f&&f.focus()},30);return m};
CG.confirm=(title,text,yesLabel,onYes)=>{const m=CG.modal(`<div class="modal-head"><div><div class="eyebrow">Please confirm</div><h2>${esc(title)}</h2></div><button class="close" data-close>Close</button></div><p style="font-size:13px">${esc(text)}</p><p style="display:flex;gap:8px"><button class="btn danger" id="cfYes">${esc(yesLabel)}</button><button class="btn outline" data-close>Cancel</button></p>`);
  CG.$$('[data-close]',m).forEach(b=>b.onclick=CG.closeModal);CG.$('#cfYes',m).onclick=()=>{CG.closeModal();onYes()}};
CG.copyBox=(title,text)=>{const m=CG.modal(`<div class="modal-head"><div><div class="eyebrow">Export</div><h2>${esc(title)}</h2></div><button class="close" data-close>Close</button></div><textarea id="cpText" readonly style="width:100%;height:300px;font:11px monospace;padding:10px;border:1px solid #ccc">${esc(text)}</textarea><p style="display:flex;gap:8px;margin-top:10px"><button class="btn" id="cpCopy">Copy to clipboard</button><button class="btn outline" id="cpDl">Download file</button></p>`,{wide:true});
  CG.$('#cpCopy',m).onclick=()=>{const t=CG.$('#cpText',m);navigator.clipboard?.writeText(t.value).then(()=>CG.toast('Copied'),()=>{t.select();CG.toast('Press Ctrl+C to copy')})||(t.select(),CG.toast('Press Ctrl+C to copy'))};
  CG.$('#cpDl',m).onclick=()=>{try{const ext=title.toLowerCase().includes('csv')?'csv':'json';const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));a.download='common-ground-export.'+ext;document.body.appendChild(a);a.click();a.remove();CG.toast('Download started. If nothing happens, use Copy.')}catch(e){CG.toast('Download blocked here. Use Copy instead.')}}};
CG.closeModal=()=>{const bg=CG.$('#cgModal');bg&&bg.classList.remove('open')};

/* ---------- location picker ---------- */
CG.locationPicker=(el,init,opts)=>{
  init=init||{};opts=opts||{};const p=opts.prefix||'loc';
  el.innerHTML=`<div class="form-grid three">
  <div class="field"><label for="${p}C">Country</label><select id="${p}C">${Object.entries(CG.COUNTRIES).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></div>
  <div class="field"><label for="${p}1" id="${p}1l">State</label><select id="${p}1"></select></div>
  <div class="field"><label for="${p}2" id="${p}2l">LGA</label><select id="${p}2"></select></div></div>`;
  const c=CG.$('#'+p+'C',el),s1=CG.$('#'+p+'1',el),s2=CG.$('#'+p+'2',el);
  const fill1=()=>{const g=CG.GEO[c.value];CG.$('#'+p+'1l',el).textContent=g.l1;CG.$('#'+p+'2l',el).textContent=g.l2;
    s1.innerHTML=`<option value="">${opts.optional?'Any '+g.l1.toLowerCase():'Choose '+g.l1.toLowerCase()}</option>`+CG.adm1List(c.value).map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('');fill2()};
  const fill2=()=>{const g=CG.GEO[c.value];s2.innerHTML=`<option value="">${s1.value?(opts.optional?'Any '+g.l2:'Choose '+g.l2):'Choose '+g.l1.toLowerCase()+' first'}</option>`+(s1.value?CG.adm2List(c.value,s1.value).map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join(''):'');s2.disabled=!s1.value};
  c.value=init.country||CG.country();if(opts.lockCountry)c.disabled=true;fill1();if(init.adm1){s1.value=init.adm1;fill2();if(init.adm2)s2.value=init.adm2}
  c.onchange=fill1;s1.onchange=fill2;
  return{get:()=>({country:c.value,adm1:s1.value,adm2:s2.value}),el};
};

/* ---------- sign in ---------- */
CG.openSignIn=(after)=>{
  const a=Math.ceil(Math.random()*8)+1,b=Math.ceil(Math.random()*8)+1;
  const m=CG.modal(`<div class="modal-head"><div><div class="eyebrow">Contributor account</div><h2>Sign in with Google</h2></div><button class="close" data-close>Close</button></div>
  <p style="font-size:12px;color:var(--muted)">Use your Gmail address. New addresses create a contributor account. <b>Demo:</b> this prototype checks the address format only and does not contact Google.</p>
  <form id="siForm"><div class="form-grid"><div class="field"><label for="siEmail">Gmail address</label><input id="siEmail" type="email" required placeholder="name@gmail.com" autocomplete="email"></div>
  <div class="field"><label for="siName">Display name</label><input id="siName" required maxlength="40" placeholder="Your name"></div></div>
  <div id="siLoc"></div>
  <div class="field"><label for="siHuman">Human check: what is ${a} + ${b}?</label><input id="siHuman" inputmode="numeric" required></div>
  <label class="check"><input type="checkbox" id="siConsent" required> I agree to take part in research under the privacy notice. My answers are stored against my area, never published individually.</label>
  <p style="margin-top:16px"><button class="btn" type="submit">Continue</button></p><div id="siErr" class="smallnote" style="color:var(--danger)"></div></form>`);
  const picker=CG.locationPicker(CG.$('#siLoc',m),{country:CG.country()},{prefix:'si'});
  const em=CG.$('#siEmail',m);
  em.addEventListener('blur',()=>{const u=CG.db().users.find(x=>x.email===em.value.trim().toLowerCase());if(u){CG.$('#siName',m).value=u.name;CG.locationPicker(CG.$('#siLoc',m),u,{prefix:'si'})}});
  CG.$('#siForm',m).onsubmit=e=>{e.preventDefault();const err=CG.$('#siErr',m);
    const email=em.value.trim().toLowerCase();
    if(!/^[a-z0-9._%+-]+@gmail\.com$/.test(email)){err.textContent='Enter a Gmail address ending in @gmail.com.';return}
    if(+CG.$('#siHuman',m).value!==a+b){err.textContent='The human check answer is wrong. Try again.';return}
    const loc={country:CG.$('#siC',m).value,adm1:CG.$('#si1',m).value,adm2:CG.$('#si2',m).value};
    if(!loc.adm1||!loc.adm2){err.textContent='Choose your area so surveys can be matched to you.';return}
    const D=CG.db();let u=D.users.find(x=>x.email===email);
    if(u){if(u.status==='suspended'){err.textContent='This account is suspended. Contact support.';return}Object.assign(u,loc,{name:CG.$('#siName',m).value.trim()||u.name})}
    else{u={id:CG.uid('u'),email,name:CG.$('#siName',m).value.trim(),...loc,verified:true,status:'active',points:0,joined:Date.now()};D.users.push(u);CG.log('New contributor joined from '+CG.areaLabel(u.country,u.adm1,u.adm2))}
    CG.save();ls.set(SESSION_KEY,u.id);CG.setCountry(u.country);CG.closeModal();CG.toast('Signed in as '+u.name);
    if(after)after(u);else setTimeout(()=>location.reload(),500)};
};
CG.requireUser=fn=>{const u=CG.user();if(u)fn(u);else CG.openSignIn(u=>{fn(u);setTimeout(()=>location.reload(),1200)})};

/* ---------- take survey ---------- */
CG.openSurvey=id=>{
  const s=CG.db().surveys.find(x=>x.id===id);if(!s)return;
  const u=CG.user();
  if(!u){CG.openSignIn(()=>CG.openSurvey(id));return}
  const el=CG.eligible(s,u);
  if(!el.ok){CG.modal(`<div class="modal-head"><div><div class="eyebrow">${CG.typeLabel(s.type)}</div><h2>${esc(s.title)}</h2></div><button class="close" data-close>Close</button></div><div class="notice">${esc(el.why)}.</div>${el.done?'<a class="btn" href="account.html">See your history</a>':''}`);return}
  const qhtml=s.questions.map((q,i)=>{const name='q_'+q.id;let inner='';
    if(q.type==='single')inner=`<div class="options">${q.options.map(o=>`<label><input type="radio" name="${name}" value="${esc(o)}" required> ${esc(o)}</label>`).join('')}</div>`;
    else if(q.type==='multi')inner=`<div class="options">${q.options.map(o=>`<label><input type="checkbox" name="${name}" value="${esc(o)}"> ${esc(o)}</label>`).join('')}</div>`;
    else if(q.type==='scale')inner=`<div class="options scale">${q.options.map(o=>`<label><input type="radio" name="${name}" value="${esc(o)}" required>${esc(o)}</label>`).join('')}</div><div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-top:5px"><span>${esc(q.low||'')}</span><span>${esc(q.high||'')}</span></div>`;
    else inner=`<textarea name="${name}" maxlength="500" placeholder="Optional"></textarea>`;
    return `<div class="q" data-q="${q.id}" data-type="${q.type}"><span class="qt">${i+1}. ${esc(q.text)}</span>${inner}</div>`}).join('');
  const m=CG.modal(`<div class="modal-head"><div><div class="eyebrow">${CG.typeLabel(s.type)} · ${s.minutes} min · ${s.points} points</div><h2>${esc(s.title)}</h2></div><button class="close" data-close>Close</button></div>
  ${s.sponsor?`<div class="notice"><b>Sponsor disclosure:</b> this survey is commissioned by ${esc(s.sponsor)}. Your individual answers are not shared with the sponsor.</div>`:''}
  <p style="font-size:12px;color:var(--muted)">Your answers will be recorded for ${esc(CG.areaLabel(u.country,u.adm1,u.adm2))}. Results are only shown for areas with at least ${CG.MIN_N} responses.</p>
  <form id="svForm">${qhtml}<p style="margin-top:18px"><button class="btn" type="submit">Submit answers</button></p><div id="svErr" class="smallnote" style="color:var(--danger)"></div></form>`,{wide:true});
  CG.$('#svForm',m).onsubmit=e=>{e.preventDefault();const ans={};let missing=false;
    for(const q of s.questions){const name='q_'+q.id;
      if(q.type==='multi'){ans[q.id]=CG.$$(`input[name="${name}"]:checked`,m).map(x=>x.value);if(!ans[q.id].length)missing=q.text}
      else if(q.type==='text'){const v=CG.$(`textarea[name="${name}"]`,m).value.trim();if(v)ans[q.id]=v}
      else{const x=CG.$(`input[name="${name}"]:checked`,m);if(!x)missing=q.text;else ans[q.id]=x.value}}
    if(missing){CG.$('#svErr',m).textContent='Answer every question before submitting: "'+missing+'"';return}
    const D=CG.db();if(CG.hasTaken(s.id,u.id)){CG.closeModal();return}
    D.responses.push({id:CG.uid('r'),surveyId:s.id,userId:u.id,country:u.country,adm1:u.adm1,adm2:u.adm2,answers:ans,at:Date.now()});
    const uu=D.users.find(x=>x.id===u.id);uu.points=(uu.points||0)+s.points;CG.log(`Response to "${s.title}" from ${CG.areaName(u.adm2)}`);CG.save();
    m.innerHTML=`<div class="modal-head"><div><div class="eyebrow">Response recorded</div><h2>Thank you.</h2></div><button class="close" data-close>Close</button></div><p>You earned <b>${s.points} Analysis Points</b>. Your answer now counts towards results for ${esc(CG.areaName(u.adm2))}.</p><p style="display:flex;gap:8px;flex-wrap:wrap"><a class="btn" href="map.html" id="svMapLink">See your area on the map</a><a class="btn outline" href="account.html">My dashboard</a></p>`;
    CG.$('[data-close]',m).onclick=()=>{CG.closeModal();location.reload()};
    CG.$('#svMapLink',m).onclick=ev=>{ev.preventDefault();CG.go('map.html',{cc:u.country,adm1:u.adm1,adm2:u.adm2,survey:s.id})};
  };
};

/* ---------- petitions ---------- */
CG.petCount=p=>(p.base||0)+p.signatures.length;
CG.signPetition=(id,cb)=>{CG.requireUser(u=>{const p=CG.db().petitions.find(x=>x.id===id);if(!p)return;
  if(p.status!=='open'){CG.toast('This petition is not open for signatures');return}
  if(p.signatures.includes(u.id)){CG.toast('You have already signed this petition');return}
  p.signatures.push(u.id);CG.log(`Signature on "${p.title}"`);CG.save();CG.toast('Signed. Thank you for adding your name.');cb&&cb()})};
CG.votePetition=(id,v,cb)=>{CG.requireUser(u=>{const p=CG.db().petitions.find(x=>x.id===id);p.voters=p.voters||{};if(p.voters[u.id]){CG.toast('You have already voted on this petition');return}
  p.voters[u.id]=v;p.votes[v]=(p.votes[v]||0)+1;CG.save();CG.toast('Vote recorded');cb&&cb()})};
CG.petSupport=p=>{const y=(p.baseVotes?.yes||0)+(p.votes?.yes||0),n=(p.baseVotes?.no||0)+(p.votes?.no||0);return y+n?Math.round(y/(y+n)*100):null};

/* ---------- art (decorative vector for stories) ---------- */
CG.art=(seedStr,dark)=>{const r=rng(hash(seedStr));const fg=dark?'#ffffff':'#111111',bg=dark?'#151515':'#f1f1ed';let s=`<svg class="art" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><rect width="400" height="300" fill="${bg}"/>`;
  for(let i=0;i<14;i++){const y=20+i*20;s+=`<path d="M0 ${y} C ${100+r()*60} ${y-30+r()*60}, ${240+r()*60} ${y-30+r()*60}, 400 ${y+r()*20-10}" fill="none" stroke="${fg}" stroke-opacity="${.08+r()*.25}" stroke-width="${.6+r()*1.2}"/>`}
  for(let i=0;i<5;i++){s+=`<circle cx="${40+r()*320}" cy="${30+r()*240}" r="${3+r()*5}" fill="${i===0?'#d7ff3f':fg}" fill-opacity="${i===0?1:.6}"/>`}
  return s+'</svg>'};

/* ---------- header & footer ---------- */
const NAV=[['index.html','Home','home'],['surveys.html','Surveys','surveys'],['map.html','Local areas','map'],['journal.html','Analysis journal','journal'],['petitions.html','Petitions Africa','petitions'],['account.html','My dashboard','account'],['admin.html','Admin','admin']];
CG.renderChrome=()=>{
  const page=document.body.dataset.page;const u=CG.user();
  const h=CG.$('#siteHeader');
  if(h){h.outerHTML=`<div class="topline"></div><header class="site"><div class="wrap nav"><a href="index.html" class="brand">COMMON <em>/</em> GROUND</a>
  <nav class="navlinks" id="navlinks" aria-label="Main">${NAV.map(([href,label,key])=>`<a href="${href}" class="${key===page?'current':''}">${label}</a>`).join('')}</nav>
  <div class="navright">${u?`<a class="btn outline small" id="signInBtn" href="account.html">${esc(u.name.split(' ')[0])} · ${CG.fmt(u.points)} pts</a>`:`<button class="btn outline small" id="signInBtn">Sign in</button>`}
  <select class="country-select" id="countrySelect" aria-label="Choose country">${Object.entries(CG.COUNTRIES).map(([k,v])=>`<option value="${k}" ${k===CG.country()?'selected':''}>${v}</option>`).join('')}</select>
  <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navlinks">Menu</button></div></div></header>`;
    if(!u)CG.$('#signInBtn').onclick=()=>CG.openSignIn();
    CG.$('#menuBtn').onclick=e=>{const n=CG.$('#navlinks');n.classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',n.classList.contains('open'))};
    CG.$('#countrySelect').onchange=e=>{CG.setCountry(e.target.value);document.dispatchEvent(new CustomEvent('cg:country',{detail:e.target.value}))};
  }
  const f=CG.$('#siteFooter');
  if(f)f.outerHTML=`<footer class="site"><div class="wrap footer-row"><div><a href="index.html" class="brand">COMMON <em>/</em> GROUND</a><p>African public opinion and civic intelligence. Nigeria, Ghana and Kenya. Boundaries: geoBoundaries (GRID3 Nigeria 2022, Ghana Statistical Service, IEBC Kenya), CC BY. Survey figures shown are demonstration data until fieldwork is verified.</p></div>
  <div class="footlinks">${NAV.slice(1).map(([h,l])=>`<a href="${h}">${l}</a>`).join('')}<a href="about.html">Methods &amp; privacy</a></div></div></footer>`;
};
document.addEventListener('DOMContentLoaded',()=>{CG.db();CG.renderChrome()});
})();
