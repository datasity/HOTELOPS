/* Common Ground SVG map engine. Self-contained: draws bundled boundaries, no tiles or external services.
   new CGMap(el,{country, values(level,parentId)->{data:{id:number|null},fmt:fn,label,domain:[min,max]}, onChange(state)}) */
(function(){
'use strict';
const NS='http://www.w3.org/2000/svg';
const RAMP=['#ecece6','#cfcfc8','#a8a8a0','#7a7a73','#4b4b47','#1f1f1d'];
const NODATA='#fafaf7';
function decode(rings,k){ // delta-encoded ints (x1000) -> path string in projected units
  let d='';
  for(const poly of rings)for(const r of poly){let x=r[0],y=r[1];d+='M'+(x*k).toFixed(1)+' '+(-y)+'';
    for(let i=2;i<r.length;i+=2){x+=r[i];y+=r[i+1];d+='L'+(x*k).toFixed(1)+' '+(-y)}d+='Z'}
  return d;
}
class CGMap{
  constructor(el,opts){
    this.el=el;this.o=opts||{};this.state={cc:null,adm1:null,adm2:null};this.paths={};
    el.classList.add('map-frame');
    el.innerHTML=`<div class="mapcaption"><span class="eyebrow" data-r="lvl"></span><strong data-r="title"></strong><span data-r="sub"></span></div>
    <div class="maptools"><button type="button" data-a="in" title="Zoom in" aria-label="Zoom in">+</button><button type="button" data-a="out" title="Zoom out" aria-label="Zoom out">−</button><button type="button" data-a="fit" title="Fit to view" aria-label="Fit to view">⤢</button><button type="button" data-a="up" title="Up one level" aria-label="Up one level">↑</button></div>
    <svg role="img" aria-label="Map"><g data-l="ctx"></g><g data-l="areas"></g><g data-l="outline"></g><g data-l="labels"></g></svg>
    <div class="legend"><div data-r="legendTitle" style="font-weight:800"></div><div class="ramp">${RAMP.map(c=>`<i style="background:${c}"></i>`).join('')}</div><div class="ends"><span data-r="lo"></span><span data-r="hi"></span></div><div style="margin-top:5px;display:flex;gap:5px;align-items:center"><i style="display:inline-block;width:12px;height:9px;background:${NODATA};border:1px solid #ccc"></i><span>No data or under 5 responses</span></div></div>
    <div class="maptip hidden"></div><div class="maploading">Loading boundaries…</div>`;
    this.svg=el.querySelector('svg');this.L={};el.querySelectorAll('[data-l]').forEach(g=>this.L[g.dataset.l]=g);
    this.R={};el.querySelectorAll('[data-r]').forEach(n=>this.R[n.dataset.r]=n);
    this.tip=el.querySelector('.maptip');this.loading=el.querySelector('.maploading');
    el.querySelector('.maptools').addEventListener('click',e=>{const a=e.target.closest('button')?.dataset.a;if(!a)return;
      if(a==='in')this.zoomBy(.6);else if(a==='out')this.zoomBy(1/.6);else if(a==='fit')this.fit();else this.up()});
    this._bindPanZoom();
    this.ro=new ResizeObserver(()=>this.vb&&this._apply());this.ro.observe(el);
  }
  async setCountry(cc,adm1,adm2){
    this.loading.classList.remove('hidden');this.loading.textContent='Loading boundaries…';
    try{this.geo=await CG.loadGeo(cc)}catch(e){this.loading.textContent=e.message;return}
    this.loading.classList.add('hidden');
    this.state={cc,adm1:null,adm2:null};
    const b=this.geo.bbox;this.k=Math.cos(((b[1]+b[3])/2)*Math.PI/180);this.paths={};
    this.byId={};this.geo.adm1.forEach(a=>this.byId[a.id]=a);this.geo.adm2.forEach(a=>this.byId[a.id]=a);
    if(adm1&&this.byId[adm1]){this.drill(adm1,true);if(adm2&&this.byId[adm2])this.select(adm2,true)}else this._render(true);
  }
  path(id){return this.paths[id]||(this.paths[id]=decode(this.byId[id].c,this.k))}
  box(b,pad){const k=this.k*1000;let x0=b[0]*k,x1=b[2]*k,y0=-b[3]*1000,y1=-b[1]*1000;const w=x1-x0,h=y1-y0,p=pad==null?.06:pad;return[x0-w*p,y0-h*p,w*(1+2*p),h*(1+2*p)]}
  drill(id,instant){const a=this.byId[id];if(!a)return;this.state.adm1=a.p?a.p:id;this.state.adm2=a.p?id:null;this._render(instant)}
  select(id,instant){const a=this.byId[id];if(!a)return;if(!a.p){this.drill(id,instant);return}
    if(this.state.adm1!==a.p){this.state.adm1=a.p;this.state.adm2=id;this._render(instant);return}
    this.state.adm2=this.state.adm2===id?null:id;this._highlight();this._zoomToSelection(instant);this._emit()}
  up(){if(this.state.adm2){this.state.adm2=null;this._highlight();this.fit();this._emit()}else if(this.state.adm1){this.state.adm1=null;this._render()}}
  home(){this.state.adm1=null;this.state.adm2=null;this._render()}
  refresh(){this._colour();this._emit()}
  _emit(){const s=this.state,g=this.geo;
    this.R.lvl.textContent=s.adm2?g.l2:s.adm1?g.l1+' · '+this.byId[s.adm1].k+' '+g.l2p.toLowerCase():'Country · '+g.adm1.length+' '+g.l1p.toLowerCase();
    this.R.title.textContent=s.adm2?this.byId[s.adm2].n:s.adm1?this.byId[s.adm1].n:CG.COUNTRIES[s.cc];
    this.R.sub.textContent=s.adm2?this.byId[s.adm1].n+', '+CG.COUNTRIES[s.cc]:s.adm1?'Click a '+g.l2.toLowerCase()+' for detail':'Click a '+g.l1.toLowerCase()+' to drill down';
    this.svg.setAttribute('aria-label','Map of '+this.R.title.textContent);
    this.o.onChange&&this.o.onChange({...s},this)}
  _render(instant){
    const s=this.state,g=this.geo;const ctx=this.L.ctx,ar=this.L.areas,ol=this.L.outline;
    ctx.innerHTML='';ar.innerHTML='';ol.innerHTML='';
    const mk=(id,cls,parent)=>{const p=document.createElementNS(NS,'path');p.setAttribute('d',this.path(id));p.setAttribute('class',cls);p.dataset.id=id;parent.appendChild(p);return p};
    if(!s.adm1){g.adm1.forEach(a=>mk(a.id,'area',ar))}
    else{g.adm1.forEach(a=>{if(a.id!==s.adm1)mk(a.id,'ctx',ctx)});g.adm2.forEach(a=>{if(a.p===s.adm1)mk(a.id,'area',ar)});mk(s.adm1,'focus-outline',ol)}
    this._colour();this._highlight();
    const target=s.adm1?this.box(this.byId[s.adm1].b):this.box(g.bbox,.04);
    this.home_vb=target;
    if(s.adm2)this._zoomToSelection(instant);else this._animateTo(target,instant||!this.vb);
    this._emit();
  }
  _colour(){
    const s=this.state;const v=this.o.values?this.o.values(s.adm1?2:1,s.adm1,this.state.cc):{data:{}};
    this.cur=v;const vals=Object.values(v.data).filter(x=>x!=null);
    let lo=v.domain?v.domain[0]:Math.min(...vals,0),hi=v.domain?v.domain[1]:Math.max(...vals,1);if(hi<=lo)hi=lo+1;
    this.L.areas.querySelectorAll('path').forEach(p=>{const x=v.data[p.dataset.id];
      if(x==null){p.style.fill=NODATA;return}
      const t=Math.max(0,Math.min(.9999,(x-lo)/(hi-lo)));p.style.fill=RAMP[Math.floor(t*RAMP.length)]});
    const f=v.fmt||(x=>CG.fmt(x));this.R.legendTitle.textContent=v.label||'';this.R.lo.textContent=f(lo);this.R.hi.textContent=f(hi);
  }
  _highlight(){this.L.areas.querySelectorAll('path').forEach(p=>p.classList.toggle('sel',p.dataset.id===this.state.adm2));
    const sel=this.L.areas.querySelector('.sel');if(sel)this.L.areas.appendChild(sel)}
  _zoomToSelection(instant){const s=this.state;if(!s.adm2){this._animateTo(this.home_vb,instant);return}
    const st=this.box(this.byId[s.adm1].b,0),lg=this.box(this.byId[s.adm2].b,0);
    if(lg[2]*lg[3]>st[2]*st[3]*.05){this._animateTo(this.home_vb,instant);return}
    const cx=lg[0]+lg[2]/2,cy=lg[1]+lg[3]/2,w=Math.max(lg[2]*4,st[2]*.22),h=Math.max(lg[3]*4,st[3]*.22);
    this._animateTo([cx-w/2,cy-h/2,w,h],instant)}
  fit(){this._animateTo(this.home_vb)}
  zoomBy(f,cx,cy){const v=this.vb;cx=cx??v[0]+v[2]/2;cy=cy??v[1]+v[3]/2;const w=v[2]*f,h=v[3]*f;
    const full=this.box(this.geo.bbox,.3);if(w>full[2]*1.2&&f>1)return;if(w<5&&f<1)return;
    this._animateTo([cx-(cx-v[0])*f,cy-(cy-v[1])*f,w,h],false,180)}
  _animateTo(t,instant,dur){cancelAnimationFrame(this._raf);if(instant||!this.vb||matchMedia('(prefers-reduced-motion: reduce)').matches){this.vb=t.slice();this._apply();this._labels();return}
    const f=this.vb.slice(),t0=performance.now(),D=dur||420;const step=now=>{let p=Math.min(1,(now-t0)/D);p=1-Math.pow(1-p,3);this.vb=f.map((x,i)=>x+(t[i]-x)*p);this._apply();if(p<1)this._raf=requestAnimationFrame(step);else this._labels()};this._raf=requestAnimationFrame(step)}
  _apply(){this.svg.setAttribute('viewBox',this.vb.map(x=>x.toFixed(1)).join(' '))}
  _scale(){const r=this.svg.getBoundingClientRect();return Math.min(r.width/this.vb[2],r.height/this.vb[3])||1}
  _labels(){const L=this.L.labels;L.innerHTML='';if(!this.geo)return;const s=this.state,sc=this._scale();
    const items=s.adm1?this.geo.adm2.filter(a=>a.p===s.adm1):this.geo.adm1;
    const fpx=s.adm1?10:11,fs=fpx/sc;const placed=[];
    const vb=this.vb;
    const sorted=items.slice().sort((a,b)=>b.a-a.a);
    for(const a of sorted){const x=a.l[0]*this.k*1000,y=-a.l[1]*1000;
      if(x<vb[0]||x>vb[0]+vb[2]||y<vb[1]||y>vb[1]+vb[3])continue;
      const bw=(a.b[2]-a.b[0])*this.k*1000*sc;const tw=a.n.length*fpx*.58;
      if(bw<tw*.75&&a.id!==s.adm2)continue;
      const box=[x*sc-tw/2,y*sc-fpx/2,x*sc+tw/2,y*sc+fpx/2];
      if(placed.some(p=>!(box[2]<p[0]||box[0]>p[2]||box[3]<p[1]||box[1]>p[3])))continue;placed.push(box);
      const t=document.createElementNS(NS,'text');t.setAttribute('x',x);t.setAttribute('y',y);t.setAttribute('font-size',fs);t.textContent=a.n;L.appendChild(t)}}
  _bindPanZoom(){
    const svg=this.svg;let drag=null,moved=false;const pts=new Map();
    const toSvg=(cx,cy)=>{const r=svg.getBoundingClientRect(),sc=this._scale();const ox=(r.width-this.vb[2]*sc)/2,oy=(r.height-this.vb[3]*sc)/2;return[this.vb[0]+(cx-r.left-ox)/sc,this.vb[1]+(cy-r.top-oy)/sc]};
    svg.addEventListener('wheel',e=>{if(!this.vb)return;e.preventDefault();const [x,y]=toSvg(e.clientX,e.clientY);this.zoomBy(e.deltaY>0?1.25:.8,x,y)},{passive:false});
    svg.addEventListener('pointerdown',e=>{pts.set(e.pointerId,[e.clientX,e.clientY]);drag={x:e.clientX,y:e.clientY,vb:this.vb.slice(),d:null};moved=false;
      if(pts.size===2){const [a,b]=[...pts.values()];drag.d=Math.hypot(a[0]-b[0],a[1]-b[1])}});
    svg.addEventListener('pointermove',e=>{
      if(!drag||!pts.has(e.pointerId)){this._hover(e);return}
      pts.set(e.pointerId,[e.clientX,e.clientY]);const sc=this._scale();
      if(pts.size===2&&drag.d){const [a,b]=[...pts.values()];const d=Math.hypot(a[0]-b[0],a[1]-b[1]);const f=drag.d/d;const v=drag.vb;const cx=v[0]+v[2]/2,cy=v[1]+v[3]/2;this.vb=[cx-v[2]*f/2,cy-v[3]*f/2,v[2]*f,v[3]*f];this._apply();moved=true;return}
      const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4){moved=true;svg.classList.add('dragging');try{svg.setPointerCapture(e.pointerId)}catch(_){}}
      if(moved){this.vb=[drag.vb[0]-dx/sc,drag.vb[1]-dy/sc,drag.vb[2],drag.vb[3]];this._apply();this.tip.classList.add('hidden')}});
    const end=e=>{pts.delete(e.pointerId);if(pts.size)return;svg.classList.remove('dragging');
      if(drag&&moved)this._labels();
      else if(drag&&e.type==='pointerup'){const t=document.elementFromPoint(e.clientX,e.clientY);const id=t&&t.dataset&&t.dataset.id;
        if(id&&t.closest('svg')===svg){if(t.classList.contains('ctx'))this.drill(id);else if(t.classList.contains('area')){if(this.byId[id].p)this.select(id);else this.drill(id)}}}
      drag=null};
    svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
    svg.addEventListener('pointerleave',()=>this.tip.classList.add('hidden'));
  }
  _hover(e){const t=e.target;const id=t.dataset&&t.dataset.id;if(!id||t.classList.contains('focus-outline')){this.tip.classList.add('hidden');return}
    const a=this.byId[id];const v=this.cur&&this.cur.data?this.cur.data[id]:undefined;const f=(this.cur&&this.cur.fmt)||(x=>CG.fmt(x));
    const r=this.el.getBoundingClientRect();
    const lvl=a.p?this.geo.l2:this.geo.l1;
    this.tip.innerHTML=`<b>${CG.esc(a.n)}</b><small>${lvl}${a.p?' · '+CG.esc(this.byId[a.p].n):''}${t.classList.contains('ctx')?' · click to open':''}</small>${!t.classList.contains('ctx')?`<small>${CG.esc(this.cur?.label||'')}: ${v==null?'insufficient data':f(v)}</small>`:''}`;
    this.tip.classList.remove('hidden');let x=e.clientX-r.left,y=e.clientY-r.top;if(x>r.width-200)x-=220;this.tip.style.left=x+'px';this.tip.style.top=y+'px'}
}
window.CGMap=CGMap;
})();
