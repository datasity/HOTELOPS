/* Shared measure picker + values function for the explorer and admin map */
(function(){
'use strict';
CG.mapMeasure=function(el,opts){
  opts=opts||{};const prefix=opts.prefix||'mm';
  el.innerHTML=`<div class="field"><label for="${prefix}S">Survey</label><select id="${prefix}S"></select></div>
  <div class="field"><label for="${prefix}M">Measure</label><select id="${prefix}M"></select><small id="${prefix}N"></small></div>`;
  const sSel=CG.$('#'+prefix+'S',el),mSel=CG.$('#'+prefix+'M',el);
  let cc=opts.country||CG.country();
  const surveysFor=c=>CG.db().surveys.filter(s=>(s.status!=='draft'||opts.includeDraft)&&(s.country==='ALL'||s.country===c));
  function fillSurveys(keep){const list=surveysFor(cc);const prev=keep||sSel.value;
    sSel.innerHTML='<option value="">All surveys</option>'+list.map(s=>`<option value="${s.id}">${CG.esc(s.title)}${s.status==='closed'?' (closed)':''}</option>`).join('');
    if(list.some(s=>s.id===prev))sSel.value=prev;fillMeasures()}
  function fillMeasures(keep){const s=CG.db().surveys.find(x=>x.id===sSel.value);const prev=keep||mSel.value;
    let h='<option value="n">Number of responses</option>';
    if(s){s.questions.filter(q=>q.type!=='text').forEach((q,i)=>{h+=`<optgroup label="Q${i+1}. ${CG.esc(q.text.length>60?q.text.slice(0,58)+'…':q.text)}">`+q.options.map((o,j)=>`<option value="${q.id}|${j}">% ${q.type==='multi'?'selecting':'answering'} “${CG.esc(o)}”</option>`).join('')+'</optgroup>'})}
    mSel.innerHTML=h;if([...mSel.options].some(o=>o.value===prev))mSel.value=prev;else if(s&&mSel.options.length>1)mSel.selectedIndex=1;note()}
  function note(){const n=CG.db().responses.filter(r=>r.country===cc&&(!sSel.value||r.surveyId===sSel.value)).length;CG.$('#'+prefix+'N',el).textContent=CG.fmt(n)+' responses in '+CG.COUNTRIES[cc]+'. Shares hidden where fewer than '+CG.MIN_N+'.'}
  sSel.onchange=()=>{fillMeasures('__reset');opts.onChange&&opts.onChange()};mSel.onchange=()=>{note();opts.onChange&&opts.onChange()};
  const api={
    setCountry(c){cc=c;fillSurveys()},
    setSurvey(id){sSel.value=id;fillMeasures();opts.onChange&&opts.onChange()},
    get(){const s=CG.db().surveys.find(x=>x.id===sSel.value);const m=mSel.value;
      if(m==='n'||!s)return{surveyId:sSel.value||null,mode:'n'};const [qid,j]=m.split('|');const q=s.questions.find(x=>x.id===qid);return{surveyId:s.id,mode:'share',qid,option:q.options[+j],q}},
    values(level,parent,c){const g=api.get();const agg=CG.aggregate(c||cc,level,{surveyId:g.surveyId,parent,qid:g.qid,option:g.option});const data={};
      for(const k in agg)data[k]=g.mode==='n'?agg[k].n:agg[k].share;
      if(g.mode==='n')return{data,label:'Responses',fmt:x=>CG.fmt(Math.round(x)),raw:agg};
      return{data,label:'% “'+g.option+'”',fmt:x=>Math.round(x)+'%',raw:agg}},
    describe(){const g=api.get();return g.mode==='n'?'Responses':'% “'+g.option+'”'}
  };
  fillSurveys(opts.survey);if(opts.measure)fillMeasures(opts.measure);
  return api;
};
/* bars for one area's results on a survey */
CG.areaResults=function(survey,filter){
  const res=CG.db().responses.filter(r=>r.surveyId===survey.id&&(!filter.country||r.country===filter.country)&&(!filter.adm1||r.adm1===filter.adm1)&&(!filter.adm2||r.adm2===filter.adm2));
  return{n:res.length,questions:survey.questions.map(q=>{
    if(q.type==='text')return{q,texts:res.map(r=>r.answers[q.id]).filter(Boolean)};
    const counts=q.options.map(o=>res.filter(r=>{const a=r.answers[q.id];return Array.isArray(a)?a.includes(o):a===o}).length);
    return{q,counts,n:res.length}})}
};
CG.barsHTML=function(qr,limitText){
  if(qr.texts)return `<div class="textanswers">${qr.texts.length?qr.texts.slice(0,limitText||40).map(t=>`<div>${CG.esc(t)}</div>`).join(''):'<div>No written answers yet.</div>'}</div>`;
  if(qr.n<CG.MIN_N)return `<p class="smallnote">Fewer than ${CG.MIN_N} responses. Results hidden to protect respondents.</p>`;
  return `<div class="mini-bars">${qr.q.options.map((o,i)=>{const p=qr.counts[i]/qr.n*100;return `<div class="mini-bar"><div><span>${CG.esc(o)}</span><span>${Math.round(p)}%</span></div><div class="bar"><span style="width:${p.toFixed(1)}%"></span></div></div>`}).join('')}</div>`;
};
})();
