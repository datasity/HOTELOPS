COMMON / GROUND  -  multi-page prototype
Open index.html in any modern browser. No internet or map service needed: all boundaries are bundled.

Pages: index (home), surveys, map (local areas explorer), journal, article, petitions, account (contributor dashboard), admin, about.
Admin password (demo): commonground

Maps (assets/geo/*.js) - built from geoBoundaries:
  Nigeria  37 states / 774 LGAs   GRID3 2022, CC BY 4.0 (every state's LGA count matches the official list)
  Ghana    16 regions / 260 districts   Ghana Statistical Service 2019, CC BY 4.0
  Kenya    47 counties / 290 constituencies   IEBC 2020, CC BY 3.0 IGO
Each local area is linked to its parent by spatial overlap. Click a state to drill down, click an LGA for detail.

Data: stored in the browser (localStorage). Seeded survey responses are demo data generated at load;
Admin > Settings can remove them or reset everything. Production needs Google OAuth, a server database,
server-side eligibility checks, rate limits, moderation and audit logs.

src/ holds page sources; build with build_scripts/build_pages.py. scripts/build_geo.py rebuilds the maps.
