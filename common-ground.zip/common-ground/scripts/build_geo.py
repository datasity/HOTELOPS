import json, sys
from shapely.geometry import shape, mapping
from shapely.validation import make_valid
from shapely.ops import unary_union, polylabel
def lp(g):
    try:
        p=max(([g] if g.geom_type=='Polygon' else list(g.geoms)),key=lambda x:x.area)
        q=polylabel(p,0.005)
    except Exception:
        q=g.representative_point()
    return [round(q.x,3),round(q.y,3)]
SRC='/home/claude/geo'; OUT='/home/claude/common-ground/assets/geo'
CFG={
 'NG':dict(iso='NGA',l1='State',l1p='States',l2='LGA',l2p='Local Government Areas',
   ren={'Abuja Federal Capital Territory':'Federal Capital Territory'}),
 'GH':dict(iso='GHA',l1='Region',l1p='Regions',l2='District',l2p='Districts',ren={}),
 'KE':dict(iso='KEN',l1='County',l1p='Counties',l2='Constituency',l2p='Constituencies',ren={'Tharaka':'Tharaka-Nithi'}),
}
NG_EXPECT={'Abia':17,'Adamawa':21,'Akwa Ibom':31,'Anambra':21,'Bauchi':20,'Bayelsa':8,'Benue':23,'Borno':27,'Cross River':18,'Delta':25,'Ebonyi':13,'Edo':18,'Ekiti':16,'Enugu':17,'Federal Capital Territory':6,'Gombe':11,'Imo':27,'Jigawa':27,'Kaduna':23,'Kano':44,'Katsina':34,'Kebbi':21,'Kogi':21,'Kwara':16,'Lagos':20,'Nasarawa':13,'Niger':25,'Ogun':20,'Ondo':18,'Osun':30,'Oyo':33,'Plateau':17,'Rivers':23,'Sokoto':23,'Taraba':16,'Yobe':17,'Zamfara':14}

def enc(geom, tol):
    g = geom.simplify(tol, preserve_topology=True)
    if g.is_empty: g = geom
    polys = [g] if g.geom_type=='Polygon' else [p for p in getattr(g,'geoms',[]) if p.geom_type=='Polygon']
    out=[]
    for p in polys:
        if p.area < (tol*tol*2) and len(polys)>1: continue
        rings=[]
        for ring in [p.exterior]+list(p.interiors):
            cs=[(round(x*1000),round(y*1000)) for x,y in ring.coords]
            ded=[cs[0]]
            for c in cs[1:]:
                if c!=ded[-1]: ded.append(c)
            if len(ded)<4: continue
            flat=[ded[0][0],ded[0][1]]
            for i in range(1,len(ded)):
                flat += [ded[i][0]-ded[i-1][0], ded[i][1]-ded[i-1][1]]
            rings.append(flat)
        if rings: out.append(rings)
    return out

def bbox(g):
    a=g.bounds; return [round(a[0],3),round(a[1],3),round(a[2],3),round(a[3],3)]

INDEX={}
for cc,c in CFG.items():
    f1=json.load(open(f"{SRC}/{c['iso']}_ADM1.geojson"))['features']
    f2=json.load(open(f"{SRC}/{c['iso']}_ADM2.geojson"))['features']
    a1=[]
    for f in f1:
        n=f['properties']['shapeName'].strip()
        n=c['ren'].get(n,n)
        if cc=='GH': n=n.replace(' Region','')
        a1.append({'name':n,'g':make_valid(shape(f['geometry']))})
    a1.sort(key=lambda x:x['name'])
    for i,x in enumerate(a1): x['id']=f"{cc}.{i+1:02d}"
    a2=[]
    for f in f2:
        g=make_valid(shape(f['geometry']))
        best=None;ba=0
        for s in a1:
            if not s['g'].intersects(g): continue
            ar=s['g'].intersection(g).area
            if ar>ba: ba,best=ar,s
        if best is None or ba/g.area<0.5:
            print('WARN weak parent',cc,f['properties']['shapeName'], best and best['name'], ba/g.area); 
        a2.append({'name':f['properties']['shapeName'].strip(),'g':g,'p':best['id']})
    # ADM1 geometry: dissolve from ADM2 so borders match exactly
    country=unary_union([s['g'] for s in a1])
    data={'code':cc,'l1':c['l1'],'l1p':c['l1p'],'l2':c['l2'],'l2p':c['l2p'],'bbox':bbox(country),'adm1':[],'adm2':[]}
    counts={}
    for s in a1:
        kids=sorted([x for x in a2 if x['p']==s['id']],key=lambda x:x['name'])
        counts[s['name']]=len(kids)
        for j,k in enumerate(kids): k['id']=f"{s['id']}.{j+1:03d}"
        dis=unary_union([k['g'] for k in kids]) if kids else s['g']
        data['adm1'].append({'id':s['id'],'n':s['name'],'b':bbox(dis),'c':enc(dis,0.004 if cc!='GH' else 0.003),'k':len(kids),'l':lp(dis),'a':round(dis.area,4)})
        for k in kids:
            data['adm2'].append({'id':k['id'],'n':k['name'],'p':s['id'],'b':bbox(k['g']),'c':enc(k['g'],0.0015),'l':lp(k['g']),'a':round(k['g'].area,5)})
    data['outline']=enc(country,0.006)
    print(cc,'ADM1',len(data['adm1']),'ADM2',len(data['adm2']))
    if cc=='NG':
        bad={k:(v,NG_EXPECT.get(k)) for k,v in counts.items() if NG_EXPECT.get(k)!=v}
        print(' NG mismatches vs official LGA counts:',bad)
    else:
        print(' ',counts)
    js=f"window.CG_GEO=window.CG_GEO||{{}};window.CG_GEO.{cc}="+json.dumps(data,separators=(',',':'),ensure_ascii=False)+";\n"
    open(f"{OUT}/{cc.lower()}.js",'w').write(js)
    print(' size',len(js)//1024,'KB')

    INDEX[cc]={'l1':c['l1'],'l1p':c['l1p'],'l2':c['l2'],'l2p':c['l2p'],'adm1':[[a['id'],a['n']] for a in data['adm1']],'adm2':[[a['id'],a['n'],a['p']] for a in data['adm2']]}
open(f"{OUT}/index.js",'w').write("window.CG_GEOINDEX="+json.dumps(INDEX,separators=(',',':'),ensure_ascii=False)+";\n")
